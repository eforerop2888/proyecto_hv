<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en">
  <head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <title>
      RECUPERACIÓN DE CONTRASEÑA SIMPLE
    </title>
	<style type="text/css">
	a:hover { text-decoration: none !important; }
	.header h1 {color: #fff !important; font: normal 33px Georgia, serif; margin: 0; padding: 0; line-height: 33px;}
	.header p {color: #dfa575; font: normal 11px Georgia, serif; margin: 0; padding: 0; line-height: 11px; letter-spacing: 2px}
	.content h2 {color:#8598a3 !important; font-weight: normal; margin: 0; padding: 0; font-style: italic; line-height: 30px; font-size: 30px;font-family: Georgia, serif; }
	.content p {color:#767676; font-weight: normal; margin: 0; padding: 0; line-height: 20px; font-size: 12px;font-family: Georgia, serif;}
	.content a {color: #d18648; text-decoration: none;}
	.footer p {padding: 0; font-size: 11px; color:#fff; margin: 0; font-family: Georgia, serif;}
	.footer a {color: #f7a766; text-decoration: none;}
	</style>
  </head>
  <body style="margin: 0; padding: 0; background: #bccdd9;">
  	<table cellpadding="0" cellspacing="0" border="0" align="center" width="100%">
		  <tr>
		  	<td align="center" style="margin: 0; padding: 0; background:#bccdd9; padding: 35px 0">
			    <table cellpadding="0" cellspacing="0" border="0" align="center" width="650" style="font-family: Georgia, serif;" class="header">
			      <tr>
			        <td bgcolor="#015bd9" height="115" align="center">
						<img src="http://www.pagosimple.com/wp-content/uploads/simple-2L.png" width="280px">
			        </td>
			      </tr>
				  <tr>
					  <td style="font-size: 1px; height: 5px; line-height: 1px;" height="5">&nbsp;</td>
				  </tr>	
				</table><!-- header-->
				<table cellpadding="0" cellspacing="0" border="0" align="center" width="650" style="font-family: Georgia, serif; background: #fff;" bgcolor="#ffffff">
			      <tr>
			        <td width="14" style="font-size: 0px;" bgcolor="#ffffff">&nbsp;</td>
					<td width="620" valign="top" align="left" bgcolor="#ffffff" style="font-family: Georgia, serif; background: #fff; padding: 0 0 10px;" class="content">
						<table cellpadding="0" cellspacing="0" border="0" style="color: #717171; font: normal 11px Georgia, serif; margin: 0; padding: 0;" width="620">
						<tr>
							<td style="padding: 25px 0 5px; border-bottom: 2px solid #d2b49b;font-family: Georgia, serif; " valign="top" align="center">
								<h3 style="color:#767676; font-weight: normal; margin: 0; padding: 0; font-style: italic; line-height: 13px; font-size: 13px;">
									
								</h3>
							</td>
						</tr>
						<repeater>
						<tr>
							<td valign="top" style="padding: 0; margin: 0">
								<table cellpadding="0" cellspacing="0" border="0" style="color: #717171; font: normal 11px Georgia, serif; margin: 0; padding: 0;" width="620">	
								<tr>
									<td style="padding: 25px 0 0;" align="left">			
										<h2 style="color:#8598a3 !important; font-weight: normal; margin: 0; padding: 0; font-style: italic; line-height: 30px; font-size: 30px;font-family: Georgia, serif; ">
											<singleline label="Title">
												NOTIFICACION HOJAS DE VIDA
											</singleline>
										</h2>
									</td>
								</tr>
								<tr>
									<td style="padding: 15px 0 15px; border-bottom: 1px solid #d2b49b;" valign="top"> 										
										<img width="300" style="padding-bottom: 15px; padding-left: 15px;" align="right" editable="true" label="Image" />
										<p>
										<multiline label="Description">
											<p>Una nueva hoja de vida fue cargada al sistema</p>
											<p>Aspirante: <strong><?php echo $nombre; ?></strong></p>
										</multiline></p>
									</td>
								</tr>
								</table>
							</td>
						</tr>		
						</repeater>
						</table>
						<br /><br />	
					</td>
					<td width="16" bgcolor="#ffffff" style="font-size: 0px; font-family: Georgia, serif; background: #fff;">&nbsp;</td>
			      </tr>
				</table><!-- body -->
				<table cellpadding="0" cellspacing="0" border="0" align="center" width="650" style="font-family: Georgia, serif; line-height: 10px;" bgcolor="#698291" class="footer">
			      <tr>
			        <td bgcolor="#015bd9" align="center" style="padding: 15px 0 10px; font-size: 11px; color:#fff; margin: 0; line-height: 1.2;font-family: Georgia, serif;" valign="top">
						<p style="padding: 0; font-size: 11px; color:#fff; margin: 0; font-family: Georgia, serif;"> © 2017 Simple S.A. Todos los derechos reservados </p>
					</td>
			      </tr>
				</table><!-- footer-->
		  	</td>
		</tr>
    </table>
  </body>
</html>
