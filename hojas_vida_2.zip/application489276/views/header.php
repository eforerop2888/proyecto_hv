<header>
	<nav>
		<img src="<?php echo base_url(); ?>asset/img/logo_simple.png" class="logo_simple">
	</nav>	
</header>