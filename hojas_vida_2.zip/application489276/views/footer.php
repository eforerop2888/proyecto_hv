<footer>
	© 2017 Simple S.A. Todos los derechos reservados
</footer>